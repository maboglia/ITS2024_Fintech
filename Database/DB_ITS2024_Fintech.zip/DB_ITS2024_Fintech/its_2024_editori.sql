-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: its_2024
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `editori`
--

DROP TABLE IF EXISTS `editori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `editori` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `editori`
--

LOCK TABLES `editori` WRITE;
/*!40000 ALTER TABLE `editori` DISABLE KEYS */;
INSERT INTO `editori` VALUES (1,'Acquarelli'),(2,'Adelphi'),(3,'Apogeo'),(4,'Atlante'),(5,'Baldini Castoldi Dalai'),(6,'Bompiani'),(7,'Camerapix'),(8,'Cantagalli'),(9,'Casa editrice ALLHM'),(10,'Coronet'),(11,'Dario Flaccovio Editore'),(12,'Demetra'),(13,'Dial Press Trade Paperbacks'),(14,'Donzelli Editore'),(15,'Edizioni Gaia'),(16,'Edizioni Giannatelli'),(17,'edizioni SÃ¬'),(18,'Einaudi'),(19,'europa edizioni'),(20,'Feltrinelli'),(21,'Garzanti'),(22,'Hoepli'),(23,'Il Saggiatore'),(24,'Istituto Poligrafico e Zecca dello Stato'),(25,'Jackson Italiana Editrice'),(26,'Kyle Cathie Limited'),(27,'La nave di Teseo'),(28,'Laterza'),(29,'Liberilibri'),(30,'LIPU'),(31,'Longanesi'),(32,'MANNI'),(33,'Marsilio'),(34,'Marsilio Lucciole'),(35,'Mondadori'),(36,'Newton Compton Editore'),(37,'Nkui Inc'),(38,'O\'REALLY'),(39,'OBJETIVA'),(40,'Officina Studi Medievali'),(41,'PIEMME'),(42,'PRIMA TECH'),(43,'Rizzoli'),(44,'Sellerio'),(45,'Slow Food Editore'),(46,'Sperling $ Kupfer'),(47,'SUPER ET OPERA VIVA'),(48,'Tecniche nuove'),(49,'Touring Club Italiano'),(50,'Ugo Guanda Editore');
/*!40000 ALTER TABLE `editori` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-12 11:45:19

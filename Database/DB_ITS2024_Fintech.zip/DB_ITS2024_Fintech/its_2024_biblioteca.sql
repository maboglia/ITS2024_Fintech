-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: its_2024
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `biblioteca`
--

DROP TABLE IF EXISTS `biblioteca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biblioteca` (
  `Codice` text,
  `Autore` text,
  `Titolo` text,
  `Editore` text,
  `Anno` bigint DEFAULT NULL,
  `Luogo` text,
  `Pagine` int DEFAULT NULL,
  `Classificazione` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblioteca`
--

LOCK TABLES `biblioteca` WRITE;
/*!40000 ALTER TABLE `biblioteca` DISABLE KEYS */;
INSERT INTO `biblioteca` VALUES ('L119','Trilussa','I Sonetti','Mondadori',1922,'',0,'Poesia'),('L387','Umberto Eco','Il Fascismo Eterno','La nave di Teseo',2018,'Milano',50,'Saggi'),('L414','Hermann Hesse','Siddharta','Adelphi',1996,'',0,'Romanzo'),('L395','Michela Murgia','Istruzioni per diventare fascisti','SUPER ET OPERA VIVA',2018,'',0,'Sociologia'),('L397','Antonio Manzini','Fater il vostro gioco','Sellerio',2018,'Palermo',0,'Romanzo'),('L402','Luis Fernando Verissimo','O melhor das Comedias da Vida Privada','OBJETIVA',2013,'Rio de Janeiro',0,'Racconti'),('L626','Tom Shore','Pilgrim Spy','Coronet',2018,'UK',0,'Spionaggio'),('L665','Philippe Daverio','Grand Tour d\'Italia a piccoli passi','Rizzoli',2018,'',0,'Arte'),('L670','Paul Lowe','1001 Fotografie da vedere nella vita','Atlante',2017,'',960,'Fotografia'),('L671','Francesco Amodeo','La Matrix Europea','edizioni SÃ¬',2018,'',0,'Politica'),('L699','Umberto Eco','Migrazioni e intolleranza','La Nave di Teseo',2019,'',0,'Saggi'),('L712','PLUTO Linux User Group','Linux How To','Apogeo',1996,'',0,'Informatica'),('L713','Joe Brockmeier','Slackware Linux 7','PRIMA TECH',2000,'',0,'Informatica'),('L715','Alessandro Vespignani, Rosita Rijitano','L\'algoritmo e l\'oracolo','Il Saggiatore',2019,'',0,'Saggi'),('L716','Guido Saraceni','Fuoco Ã¨ tutto ciÃ² che siamo','Sperling $ Kupfer',2019,'',0,'Romanzo'),('L717','Paolo Rumiz','Il filo infinito','Feltrinelli',2019,'',0,'Storia'),('L718','Andrea Vitali','Documenti, prego','Einaudi',2019,'',0,'Romanzo'),('L720','vari','Sicilia','Touring Club Italiano',2018,'',0,'Viaggi'),('L721','Andrea Camilleri','Il cuoco dell\'Alcyon','Sellerio',2019,'',0,'Romanzo'),('L722','Hans Fallada','Ognuno muore solo','Sellerio',2017,'',0,'Romanzo'),('L749','Maurizio Viroli','Nazionalisti e Patrioti','Laterza',2019,'',0,'Saggi'),('L750','Chiara Mercuri','Francesco d\'Assisi, la storia negata','Laterza',2018,'',0,'Storia'),('L751','Alessandro Mulieri','Democrazia Totalitaria','Donzelli Editore',2019,'Roma',215,'Saggi'),('L752','Howard M. Berlin','La progettazione dei circuiti amplificaori operazionali','Jackson Italiana Editrice',1979,'Milano',0,'Elettronica'),('L753','Howard M. Berlin','La progettazione dei filtri attivi','Jackson Italiana Editrice',1979,'Milano',0,'Elettronica'),('L754','Walter Veltroni','Assassinio a Villa Borghese','Marsilio Lucciole',2019,'Venezia',205,'Gialli'),('L755','Indro Montanelli','Storia di Roma','Rizzoli',2018,'',516,'Storia'),('L756','Luciano Lozio','Microbiota Intestinale','Tecniche nuove',2011,'',0,'Medicina'),('L757','Paolo Naso','Le religioni sono vie di pace','Laterza',2019,'Roma',0,'Saggi'),('L758','Edward Snowen','Errore di sistema','Longanesi',2019,'Milano',0,'Autobiografico'),('L759','Elena Pigozzi','Come difendersi dai Romani','Demetra',2018,'',0,'Humor'),('L760','Jonah Goldberg','Miracolo e Suicidio dell\'Occidente','Liberilibri',2019,'Macerata',0,'Politica'),('L761','Fabio Cusimano','Modo di legare i libri','Officina Studi Medievali',2014,'Palermo',0,'Hobby'),('L762','Zap e Ida','Wikibolario','Dario Flaccovio Editore',2018,'',0,'Humor'),('L763','Andrea Camilleri','Autodifesa di Caino','Sellerio',2019,'Palermo',79,'Teatro'),('L764','Italo Svevo','Una Vita','Garzanti',2019,'',356,'Romanzo'),('L765','Italo Svevo','La Coscienza di Zeno','Feltrinelli',2019,'',413,'Romanzo'),('L766','Italo Svevo','SenilitÃ ','Feltrinelli',2018,'',225,'Romanzo'),('L769','Nigel Pavitt','Samburu','Kyle Cathie Limited',2006,'',0,'Viaggi'),('L770','Mariavittoria Carnovale, Aldo Chietera','Matera','Edizioni Giannatelli',2003,'',0,'Viaggi'),('L771','Johan Beck-Friis','Il Cimitero Acattolico di Roma','Casa editrice ALLHM',2013,'',0,'Archeologia'),('L777','Alessandro Roccati','Museo Egizio di Torino','Istituto Poligrafico e Zecca dello Stato',1999,'',0,'Archeologia'),('L783','Piero Gelli','Dizionario dell\'Opera 2008','Baldini Castoldi Dalai',2007,'',0,'Musica'),('L785','Marco Gustin, Mattia Brambilla, Claudio Celada','Conoscerli, Proteggerli','LIPU',2019,'',0,'Ambiente'),('L786','Francesco Sinagra','Il Ghetto di Roma','Edizioni Gaia',2007,'',0,'Archeologia'),('L789','Vari','Osterie d\'Italia 2020','Slow Food Editore',2019,'',0,'Cucina'),('L790','Roberto Calasso','Il Libro di Tutti i Libri','Adelphi',2019,'',0,'Saggi'),('L791','Chris Knight','Il Ritratto Perfetto','Apogeo',2019,'',224,'Fotografia'),('L792','Corrado Augias, Giovanni Filoramo','Il Grande Romanzo dei Vangeli','Einaudi',2019,'',0,'Storia'),('L793','Melania Gaia Mazzucco','L\'Architettrice','Einaudi',2019,'',0,'Romanzo'),('L797','Valerio Massimo Manfredi','Antica Madre','Mondadori',2019,'',0,'Romanzo'),('L798','Yuval Noah Harari','21 Lezioni per il XXI Secolo','Bompiani',2018,'',520,'Saggi'),('L799','Heather Dune Macadam','Le 999 donne di Auschwitz','Newton Compton Editore',2019,'',330,'Romanzo'),('L802','Dean Koontz','The Eyes of Darkness','Nkui Inc',1981,'',0,'Romanzo'),('L809','Mariapia Veladiano','Parole di scuola','Ugo Guanda Editore',2019,'',0,'Saggi'),('L810','Cosmo Giacomo Sallustio Salvemini','Epuloni e Lazzari','europa edizioni',2019,'',0,'Saggi'),('L812','Paolo Bonolis','PerchÃ¨ parlavo da solo','Rizzoli',2019,'',0,'Autobiografico'),('L816','Curzio Malaparte','Il buonuomo Lenin','Adelphi',2018,'',0,'Saggi'),('','Seneca','La tranquillitÃ  dell\'anima','Acquarelli',1996,'',62,'Classici'),('L832','Antonio Manzini','Ah l\'amore l\'amore','Sellerio',2020,'Palermo',0,'Romanzo'),('L834','Erri De Luca','Il contrario di uno','Feltrinelli',2018,'',0,'Romanzo'),('L836','Corrado Augias','Breviario per un confuso presente','Einaudi',2020,'Torino',184,'Saggi'),('L838','Andrea Camilleri','Riccardino','sellerio',2020,'',0,'Romanzo'),('L844','Erik Siegel, Adam Retter','eXist','O\'REALLY',2014,'',0,'Informatica'),('L851','Fabiano Massimi','L\'Angelo di Monaco','Longanesi',2020,'',480,'Romanzo'),('L869','Antonio Manzini','Gli ultimi giorni di quiete','Sellerio',2020,'',0,'Romanzo'),('L871','Ken Follet','Fu sera e fu mattina','Mondadori',2020,'',0,'Romanzo'),('L872','Walter Veltroni','Buonvino e il caso del bambino scomparso','Marsilio',2020,'',0,'Romanzo'),('L875','Sting','Broken Music','Dial Press Trade Paperbacks',2020,'',0,'Autobiografico'),('L881','Camerapix','The spectrum Guide to Kenya','Camerapix',1989,'',0,'Viaggi'),('L883','G.Alfano, P.Italia, E.Russo, F.Tomasi','Letteratura italiana 1Â° volume','Mondadori',2020,'',0,'Letteratura'),('L884','Philippe Daverio','Quattro conversazioni sull\'Europa','Rizzoli',2019,'',0,'Saggi'),('L887','Joseph Tritto','Cina Covid-19','Cantagalli',2020,'',0,'Attualita'),('L891','Lia Tagliacozzo','La generazione del deserto','MANNI',2020,'',0,'Romanzo'),('L892','Papa Francesco','Ritorniamo a sognare','PIEMME',2020,'',0,'Religione'),('L903','Benjamin Labatut','Quando abbiamo smesso di capire il mondo','Adelphi',2021,'',0,'Saggi'),('L904','Alessandro Barbero','Dante','Laterza',2020,'',0,'Storia'),('L907','Dante Alighieri','La Divina Commedia','Hoepli',2021,'',0,'Letteratura'),('L908','Alessandro Barbero','Alabama','Sellerio',2021,'',0,'Romanzo');
/*!40000 ALTER TABLE `biblioteca` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-12 11:45:20

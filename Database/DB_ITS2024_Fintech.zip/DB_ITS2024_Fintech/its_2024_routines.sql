-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: its_2024
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `pokemon_plus`
--

DROP TABLE IF EXISTS `pokemon_plus`;
/*!50001 DROP VIEW IF EXISTS `pokemon_plus`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `pokemon_plus` AS SELECT 
 1 AS `indice`,
 1 AS `Name`,
 1 AS `Type1`,
 1 AS `Type2`,
 1 AS `Total`,
 1 AS `HP`,
 1 AS `Attack`,
 1 AS `Defense`,
 1 AS `SpAtk`,
 1 AS `SpDef`,
 1 AS `Speed`,
 1 AS `Generation`,
 1 AS `Legendary`,
 1 AS `id`,
 1 AS `image`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `paesi_grandi`
--

DROP TABLE IF EXISTS `paesi_grandi`;
/*!50001 DROP VIEW IF EXISTS `paesi_grandi`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `paesi_grandi` AS SELECT 
 1 AS `alpha2Code`,
 1 AS `capital`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `pokemon_plus`
--

/*!50001 DROP VIEW IF EXISTS `pokemon_plus`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ITS_2024`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `pokemon_plus` AS select `pokedata`.`indice` AS `indice`,`pokedata`.`Name` AS `Name`,`pokedata`.`Type1` AS `Type1`,`pokedata`.`Type2` AS `Type2`,`pokedata`.`Total` AS `Total`,`pokedata`.`HP` AS `HP`,`pokedata`.`Attack` AS `Attack`,`pokedata`.`Defense` AS `Defense`,`pokedata`.`SpAtk` AS `SpAtk`,`pokedata`.`SpDef` AS `SpDef`,`pokedata`.`Speed` AS `Speed`,`pokedata`.`Generation` AS `Generation`,`pokedata`.`Legendary` AS `Legendary`,`pokedata`.`id` AS `id`,`pics`.`img` AS `image` from (`pokemon_data` `pokedata` left join `pokemon` `pics` on((`pokedata`.`Name` = `pics`.`name`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `paesi_grandi`
--

/*!50001 DROP VIEW IF EXISTS `paesi_grandi`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ITS_2024`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `paesi_grandi` AS select `countriesv2`.`alpha2Code` AS `alpha2Code`,`countriesv2`.`capital` AS `capital`,`countriesv2`.`name` AS `name` from `countriesv2` where (`countriesv2`.`population` > 50000000) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-12 11:45:21

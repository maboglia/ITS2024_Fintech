-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: its_2024
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `libri`
--

DROP TABLE IF EXISTS `libri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `libri` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titolo` varchar(100) DEFAULT NULL,
  `autore` varchar(100) DEFAULT NULL,
  `editore` varchar(100) DEFAULT NULL,
  `classificazione` varchar(100) DEFAULT NULL,
  `anno` int DEFAULT NULL,
  `pagine` int DEFAULT NULL,
  `luogo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libri`
--

LOCK TABLES `libri` WRITE;
/*!40000 ALTER TABLE `libri` DISABLE KEYS */;
INSERT INTO `libri` VALUES (1,'Siddharta','Hermann Hesse','Adelphi','Romanzo',1996,NULL,NULL),(2,'Fater il vostro gioco','Antonio Manzini','Sellerio','Romanzo',2018,NULL,NULL),(3,'Fuocoè¨ tutto ciò che siamo','Guido Saraceni','Sperling $ Kupfer','Romanzo',2019,NULL,NULL),(4,'Documenti, prego','Andrea Vitali','Einaudi','Romanzo',2019,NULL,NULL),(5,'Il cuoco dell\'Alcyon','Andrea Camilleri','Sellerio','Romanzo',2019,NULL,NULL),(6,'Ognuno muore solo','Hans Fallada','Sellerio','Romanzo',2017,NULL,NULL),(7,'Una Vita','Italo Svevo','Garzanti','Romanzo',2019,NULL,NULL),(8,'La Coscienza di Zeno','Italo Svevo','Feltrinelli','Romanzo',2019,NULL,NULL),(9,'SenilitÃ ','Italo Svevo','Feltrinelli','Romanzo',2018,NULL,NULL),(10,'L\'Architettrice','Melania Gaia Mazzucco','Einaudi','Romanzo',2019,NULL,NULL),(11,'Antica Madre','Valerio Massimo Manfredi','Mondadori','Romanzo',2019,NULL,NULL),(12,'Le 999 donne di Auschwitz','Heather Dune Macadam','Newton Compton Editore','Romanzo',2019,NULL,NULL),(13,'The Eyes of Darkness','Dean Koontz','Nkui Inc','Romanzo',1981,NULL,NULL),(14,'Ah l\'amore l\'amore','Antonio Manzini','Sellerio','Romanzo',2020,NULL,NULL),(15,'Il contrario di uno','Erri De Luca','Feltrinelli','Romanzo',2018,NULL,NULL),(16,'Riccardino','Andrea Camilleri','sellerio','Romanzo',2020,NULL,NULL),(17,'L\'Angelo di Monaco','Fabiano Massimi','Longanesi','Romanzo',2020,NULL,NULL),(18,'Gli ultimi giorni di quiete','Antonio Manzini','Sellerio','Romanzo',2020,NULL,NULL),(19,'Fu sera e fu mattina','Ken Follet','Mondadori','Romanzo',2020,NULL,NULL),(20,'Buonvino e il caso del bambino scomparso','Walter Veltroni','Marsilio','Romanzo',2020,NULL,NULL),(21,'La generazione del deserto','Lia Tagliacozzo','MANNI','Romanzo',2020,NULL,NULL),(22,'Alabama','Alessandro Barbero','Sellerio','Romanzo',2021,NULL,NULL);
/*!40000 ALTER TABLE `libri` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-12 11:45:19
